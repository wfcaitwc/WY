/**
 * 忍者认证接口封装
 * 请求 /api/ninja/* ，由 vite.config.js 的 proxy 转发到 Spring Boot（默认 127.0.0.1:8081）。
 * 若不用代理，可把 BASE 改成 'http://127.0.0.1:8081/api/ninja'（同时后端需允许跨域）。
 */

const BASE = '/api/ninja'

/** 成功码，与后端 R.CODE_OK 一致 */
const CODE_OK = 200

/**
 * 统一请求入口，把后端 {code,msg,data} 转成 {ok,msg,data}
 */
async function request(path, options = {}) {
  let res
  try {
    res = await fetch(BASE + path, {
      headers: { 'Content-Type': 'application/json' },
      ...options
    })
  } catch {
    return {
      ok: false,
      code: -1,
      msg: '※ 无法连接后端服务，请确认 Spring Boot 已启动（端口 8081）',
      data: null
    }
  }

  let body
  try {
    body = await res.json()
  } catch {
    return { ok: false, code: res.status, msg: `※ 响应解析失败（HTTP ${res.status}）`, data: null }
  }

  if (body == null || typeof body.code !== 'number') {
    return { ok: false, code: -1, msg: '※ 后端返回格式异常', data: null }
  }

  return {
    ok: body.code === CODE_OK,
    code: body.code,
    msg: body.msg || '',
    data: body.data
  }
}

function post(path, payload) {
  return request(path, { method: 'POST', body: JSON.stringify(payload) })
}

function get(path, params) {
  const qs = new URLSearchParams(params).toString()
  return request(qs ? `${path}?${qs}` : path, { method: 'GET' })
}

/* ---------------- 接口 ---------------- */

/** 注册 */
export function apiRegister({ uid, email, ninjaRank, password, question, answer }) {
  return post('/register', { uid, email, ninjaRank, password, question, answer })
}

/** 登录 */
export function apiLogin({ uid, password }) {
  return post('/login', { uid, password })
}

/** 编号查重 */
export function apiCheckUid(uid) {
  return get('/check-uid', { uid })
}

/** 邮箱查重 */
export function apiCheckEmail(email) {
  return get('/check-email', { email })
}

/** 取回安全问题 */
export function apiGetQuestion(uid) {
  return get('/question', { uid })
}

/** 身份核验，成功返回 data = resetToken */
export function apiVerify({ uid, email, answer }) {
  return post('/verify', { uid, email, answer })
}

/** 重置密码 */
export function apiResetPassword({ resetToken, newPassword }) {
  return post('/reset-password', { resetToken, newPassword })
}
