<script setup>
import ChakraBackground from './components/ChakraBackground.vue'
import FallingLeaves from './components/FallingLeaves.vue'
</script>

<template>
  <ChakraBackground />
  <div class="grid-overlay"></div>
  <FallingLeaves />
  <div class="vignette"></div>

  <RouterView />
</template>

<style scoped>
.grid-overlay {
  position: fixed;
  inset: 0;
  z-index: 1;
  pointer-events: none;
  background-image:
    linear-gradient(rgba(255, 140, 26, 0.045) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255, 140, 26, 0.045) 1px, transparent 1px);
  background-size: 52px 52px;
  mask-image: radial-gradient(circle at 50% 50%, #000 0%, transparent 78%);
  -webkit-mask-image: radial-gradient(circle at 50% 50%, #000 0%, transparent 78%);
}

.vignette {
  position: fixed;
  inset: 0;
  z-index: 2;
  pointer-events: none;
  background: radial-gradient(ellipse at 50% 50%, transparent 40%, rgba(0, 0, 0, 0.72) 100%);
}
</style>
