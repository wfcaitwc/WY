<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import LoginCard from '../components/LoginCard.vue'
import SealOverlay from '../components/SealOverlay.vue'
import { useNinjaStore } from '../stores/ninjaStore'

const router = useRouter()
const store = useNinjaStore()

const overlayVisible = ref(false)
const currentUser = ref({ uid: '', rank: '' })

function handleSuccess({ uid, rank }) {
  currentUser.value = { uid, rank }
  overlayVisible.value = true
}

function handleClose() {
  overlayVisible.value = false
  store.login(currentUser.value.uid, currentUser.value.rank)
  router.push({ name: 'dashboard' })
}
</script>

<template>
  <LoginCard @success="handleSuccess" />

  <SealOverlay
    :visible="overlayVisible"
    :uid="currentUser.uid"
    :rank="currentUser.rank"
    confirm-text="进 入 木 叶"
    @close="handleClose"
  />
</template>
