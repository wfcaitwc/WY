<script setup>
import ForgotCard from '../components/ForgotCard.vue'
</script>

<template>
  <ForgotCard />
</template>
