<script setup>
import { useRouter } from 'vue-router'
import VortexEmblem from '../components/VortexEmblem.vue'
import NinjaStatusCard from '../components/dashboard/NinjaStatusCard.vue'
import TaskBoard from '../components/dashboard/TaskBoard.vue'
import NewsPanel from '../components/dashboard/NewsPanel.vue'
import { useNinjaStore } from '../stores/ninjaStore'

const router = useRouter()
const { state, logout } = useNinjaStore()

function onLogout() {
  logout()
  router.push({ name: 'login' })
}
</script>

<template>
  <div class="dashboard">
    <header class="topbar">
      <div class="brand">
        <span class="emblem-mini"><VortexEmblem /></span>
        <div class="brand-text">
          <strong>木叶隐村</strong>
          <span>ninja mission terminal</span>
        </div>
      </div>

      <div class="user">
        <span class="uid">{{ state.ninja?.uid }}</span>
        <button type="button" class="logout" @click="onLogout">登 出</button>
      </div>
    </header>

    <div class="wrap">
      <div class="grid">
        <aside class="col-left">
          <NinjaStatusCard />
        </aside>

        <div class="col-right">
          <TaskBoard />
          <NewsPanel />
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.dashboard {
  position: fixed;
  inset: 0;
  z-index: 5;
  overflow-y: auto;
  overflow-x: hidden;
}

.dashboard::-webkit-scrollbar {
  width: 6px;
}
.dashboard::-webkit-scrollbar-thumb {
  background: rgba(255, 140, 26, 0.35);
  border-radius: 3px;
}

.topbar {
  position: sticky;
  top: 0;
  z-index: 10;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  padding: 14px 26px;
  background: linear-gradient(180deg, rgba(8, 10, 14, 0.95), rgba(8, 10, 14, 0.72));
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  border-bottom: 1px solid rgba(255, 140, 26, 0.26);
}

.topbar::after {
  content: '';
  position: absolute;
  left: 0;
  right: 0;
  bottom: -1px;
  height: 1px;
  background: linear-gradient(90deg, transparent, var(--orange), var(--chakra), transparent);
  opacity: 0.65;
}

.brand {
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
}

.emblem-mini {
  display: block;
  width: 42px;
  height: 42px;
  transform: scale(0.54);
  transform-origin: center;
  margin: -9px;
  flex: none;
}

.brand-text strong {
  display: block;
  font-family: var(--font-serif);
  font-size: 16px;
  letter-spacing: 0.2em;
  color: var(--orange-soft);
  text-shadow: 0 0 18px rgba(255, 140, 26, 0.35);
}

.brand-text span {
  font-size: 9.5px;
  letter-spacing: 0.3em;
  color: var(--text-dim);
  text-transform: uppercase;
}

.user {
  display: flex;
  align-items: center;
  gap: 14px;
  flex: none;
}

.uid {
  font-size: 12px;
  letter-spacing: 0.08em;
  color: var(--text);
}

.logout {
  padding: 7px 15px;
  font-size: 11px;
  letter-spacing: 0.18em;
  cursor: pointer;
  border-radius: 3px;
  border: 1px solid rgba(255, 107, 107, 0.45);
  background: rgba(255, 107, 107, 0.08);
  color: #ff9b9b;
  font-family: inherit;
  transition: 0.2s;
}

.logout:hover {
  background: rgba(255, 107, 107, 0.2);
  box-shadow: 0 0 18px rgba(255, 107, 107, 0.25);
}

.wrap {
  max-width: 1120px;
  margin: 0 auto;
  padding: 24px 26px 40px;
}

.grid {
  display: grid;
  grid-template-columns: 330px 1fr;
  gap: 20px;
  align-items: start;
}

.col-left {
  position: sticky;
  top: 92px;
}

.col-right {
  display: grid;
  gap: 20px;
  min-width: 0;
}

@media (max-width: 900px) {
  .grid {
    grid-template-columns: 1fr;
  }
  .col-left {
    position: static;
  }
}

@media (max-width: 560px) {
  .topbar {
    padding: 12px 16px;
  }
  .wrap {
    padding: 18px 16px 32px;
  }
  .brand-text span {
    display: none;
  }
}
</style>
