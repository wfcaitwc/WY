<script setup>
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import { MIN_PWD, STRENGTH_TEXT, pwdStrength, useAuthStore } from '../stores/authStore'

const router = useRouter()
const { getQuestion, verifyIdentity, resetPassword } = useAuthStore()

/** 1 输入编号 → 2 身份核验 → 3 重置密码 → done */
const step = ref(1)
const error = ref('')
const okMsg = ref('')

const uid = ref('')
const email = ref('')
const answer = ref('')
const pwd = ref('')
const pwd2 = ref('')
const showPwd = ref(false)
const shaking = ref(false)

const loading = ref(false)

/** 后端返回的安全问题文本 */
const secQuestion = ref('')
/** 身份核验通过后由后端签发的重置凭证 */
const resetToken = ref('')

function onAnimationEnd(e) {
  if (e.animationName === 'shake') shaking.value = false
}

function fail(msg) {
  error.value = msg
  okMsg.value = ''
  shaking.value = false
  requestAnimationFrame(() => {
    shaking.value = true
  })
}

const strength = computed(() => pwdStrength(pwd.value))
const strengthText = computed(() => (pwd.value ? STRENGTH_TEXT[strength.value] : ''))
const pwdError = computed(() => (pwd.value && pwd.value.length < MIN_PWD ? `※ 新密码不足 ${MIN_PWD} 位` : ''))
const pwd2Error = computed(() => (pwd2.value && pwd2.value !== pwd.value ? '※ 两次输入的密码不一致' : ''))

async function goStep1() {
  if (loading.value) return
  error.value = ''
  if (!uid.value.trim()) return fail('※ 请输入忍者编号')

  loading.value = true
  try {
    // 向后端查询该编号登记的安全问题
    const r = await getQuestion(uid.value.trim())
    if (!r.ok) return fail(r.msg || '※ 查无此编号，请确认或先注册')
    secQuestion.value = r.question || ''
    step.value = 2
  } finally {
    loading.value = false
  }
}

async function goStep3() {
  if (loading.value) return
  error.value = ''
  if (!email.value.trim()) return fail('※ 请输入邮箱地址')
  if (!answer.value.trim()) return fail('※ 请填写安全问题答案')

  loading.value = true
  try {
    // 核验通过后会拿到一次性重置凭证
    const r = await verifyIdentity(uid.value, email.value, answer.value)
    if (!r.ok) return fail(r.msg)
    resetToken.value = r.resetToken || ''
    step.value = 3
  } finally {
    loading.value = false
  }
}

async function doReset() {
  if (loading.value) return
  error.value = ''
  if (pwd.value.length < MIN_PWD) return fail(`※ 新密码至少要 ${MIN_PWD} 位`)
  if (pwd.value !== pwd2.value) return fail('※ 两次输入的密码不一致')
  if (!resetToken.value) return fail('※ 重置凭证已失效，请重新核验身份')

  loading.value = true
  try {
    const r = await resetPassword(resetToken.value, pwd.value)
    if (!r.ok) return fail(r.msg)

    okMsg.value = '密码已重置，请使用新密码登录'
    step.value = 4
  } finally {
    loading.value = false
  }
}

function restart() {
  step.value = 1
  uid.value = ''
  email.value = ''
  answer.value = ''
  pwd.value = ''
  pwd2.value = ''
  secQuestion.value = ''
  resetToken.value = ''
  error.value = ''
  okMsg.value = ''
}
</script>

<template>
  <main class="card" :class="{ shake: shaking }" @animationend="onAnimationEnd">
    <span class="corner tl"></span>
    <span class="corner tr"></span>
    <span class="corner bl"></span>
    <span class="corner br"></span>

    <h1>密 码 找 回</h1>
    <p class="sub">password recovery terminal</p>

    <div class="steps">
      <span :class="{ on: step >= 1 }">壹 · 识别</span>
      <span :class="{ on: step >= 2 }">贰 · 核验</span>
      <span :class="{ on: step >= 3 }">参 · 重设</span>
    </div>

    <!-- 壹 · 输入编号 -->
    <form v-if="step === 1" autocomplete="off" @submit.prevent="goStep1">
      <div class="field">
        <label for="f-uid"><i></i>忍者编号</label>
        <input id="f-uid" v-model="uid" type="text" placeholder="输入注册时的编号" maxlength="20" />
      </div>
      <button type="submit" class="btn">查 询 户 籍</button>
    </form>

    <!-- 贰 · 身份核验 -->
    <form v-else-if="step === 2" autocomplete="off" @submit.prevent="goStep3">
      <div class="field">
        <label for="f-email"><i></i>邮箱地址</label>
        <input id="f-email" v-model="email" type="email" placeholder="输入注册时登记的邮箱地址" maxlength="60" />
      </div>
      <div class="field">
        <label for="f-answer"><i></i>安全问题</label>
        <div class="question">{{ secQuestion || '（加载中…）' }}</div>
        <input id="f-answer" v-model="answer" type="text" placeholder="输入你当初填写的答案" maxlength="30" />
      </div>
      <button type="submit" class="btn">核 验 身 份</button>
    </form>

    <!-- 参 · 设置新密码 -->
    <form v-else-if="step === 3" autocomplete="off" @submit.prevent="doReset">
      <div class="field">
        <label for="f-pwd">
          <i></i>新的密码
          <span class="counter" :class="{ bad: pwdError }">{{ pwd.length }} / {{ MIN_PWD }}+</span>
        </label>
        <input
          id="f-pwd"
          v-model="pwd"
          :type="showPwd ? 'text' : 'password'"
          :placeholder="`至少 ${MIN_PWD} 位`"
          maxlength="32"
        />
        <button
          type="button"
          class="toggle-eye"
          :class="{ active: showPwd }"
          :aria-label="showPwd ? '隐藏密码' : '显示密码'"
          @click="showPwd = !showPwd"
        >
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z" />
            <circle cx="12" cy="12" r="3" />
          </svg>
        </button>
        <div class="meter" :class="{ on: pwd.length > 0 }">
          <span v-for="i in 4" :key="i" :class="{ lit: i <= strength }"></span>
          <em v-if="strengthText">{{ strengthText }}</em>
        </div>
        <p class="tiny-err">{{ pwdError }}</p>
      </div>

      <div class="field">
        <label for="f-pwd2"><i></i>确认新密码</label>
        <input
          id="f-pwd2"
          v-model="pwd2"
          :type="showPwd ? 'text' : 'password'"
          placeholder="再次输入相同密码"
          maxlength="32"
        />
        <p class="tiny-err">{{ pwd2Error }}</p>
      </div>

      <button type="submit" class="btn">重 设 密 码</button>
    </form>

    <!-- 完成 -->
    <div v-else class="done">
      <div class="mark">
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#ff8c1a" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
          <path d="M20 6L9 17l-5-5" />
        </svg>
      </div>
      <h2>重 设 完 了</h2>
      <p class="who">编号 <em>{{ account?.uid }}</em> 的密码已更新</p>
      <button type="button" class="btn" @click="router.push({ name: 'login' })">前 往 登 录</button>
      <button type="button" class="btn ghost" @click="restart">再 找 回 一 个</button>
    </div>

    <p class="err" :class="{ ok: !!okMsg }">{{ error || okMsg }}</p>

    <nav class="links">
      <RouterLink class="lnk" to="/login">返 回 登 录</RouterLink>
      <span class="dot">·</span>
      <RouterLink class="lnk" to="/register">注 册 新 忍 者</RouterLink>
    </nav>
  </main>
</template>

<style scoped>
.card {
  position: relative;
  z-index: 5;
  margin: auto;
  width: min(92vw, 428px);
  padding: 32px 34px 26px;
  background: linear-gradient(160deg, rgba(20, 24, 32, 0.92), rgba(8, 10, 14, 0.95));
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  border: 1px solid rgba(255, 140, 26, 0.28);
  border-radius: 6px;
  box-shadow:
    0 0 0 1px rgba(0, 0, 0, 0.6),
    0 30px 70px rgba(0, 0, 0, 0.75),
    0 0 60px rgba(255, 140, 26, 0.09) inset;
}

.card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 12%;
  right: 12%;
  height: 2px;
  background: linear-gradient(90deg, transparent, var(--orange), var(--chakra), transparent);
  box-shadow: 0 0 14px rgba(255, 140, 26, 0.7);
}

.corner {
  position: absolute;
  width: 16px;
  height: 16px;
  border: 2px solid var(--orange);
  opacity: 0.65;
}
.corner.tl { top: -1px; left: -1px; border-right: 0; border-bottom: 0; }
.corner.tr { top: -1px; right: -1px; border-left: 0; border-bottom: 0; }
.corner.bl { bottom: -1px; left: -1px; border-right: 0; border-top: 0; }
.corner.br { bottom: -1px; right: -1px; border-left: 0; border-top: 0; }

h1 {
  font-family: var(--font-serif);
  font-size: 25px;
  letter-spacing: 0.22em;
  text-align: center;
  font-weight: 700;
  background: linear-gradient(180deg, #fff3e0, var(--orange-soft) 55%, var(--orange-deep));
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  text-shadow: 0 0 26px rgba(255, 140, 26, 0.35);
}

.sub {
  text-align: center;
  font-size: 11px;
  letter-spacing: 0.34em;
  color: var(--text-dim);
  margin-top: 9px;
  text-transform: uppercase;
}

.steps {
  display: flex;
  justify-content: center;
  gap: 8px;
  margin: 22px 0 20px;
  font-size: 10px;
  letter-spacing: 0.16em;
}
.steps span {
  padding: 5px 9px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 2px;
  color: var(--text-dim);
  transition: 0.25s;
}
.steps span.on {
  color: var(--orange-soft);
  border-color: rgba(255, 140, 26, 0.55);
  background: rgba(255, 140, 26, 0.1);
  box-shadow: 0 0 16px rgba(255, 140, 26, 0.2);
}

.field {
  position: relative;
  margin-bottom: 20px;
}

.field label {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 11px;
  letter-spacing: 0.16em;
  color: var(--text-dim);
  margin-bottom: 8px;
}

.field label i {
  width: 5px;
  height: 5px;
  background: var(--orange);
  border-radius: 50%;
  box-shadow: 0 0 8px var(--orange);
  font-style: normal;
}

.counter {
  margin-left: auto;
  font-size: 10px;
  color: rgba(154, 160, 172, 0.7);
}
.counter.bad {
  color: #ff6b6b;
}

.question {
  margin-bottom: 8px;
  padding: 9px 12px;
  border-left: 2px solid rgba(255, 140, 26, 0.45);
  background: rgba(255, 140, 26, 0.06);
  font-size: 12.5px;
  color: var(--orange-soft);
  letter-spacing: 0.06em;
}

.field input {
  width: 100%;
  padding: 11px 12px;
  background: rgba(255, 255, 255, 0.035);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-left: 2px solid rgba(255, 140, 26, 0.45);
  border-radius: 3px;
  color: var(--text);
  font-size: 14px;
  letter-spacing: 0.05em;
  font-family: inherit;
  outline: none;
  transition: 0.22s;
}
.field input::placeholder {
  color: rgba(154, 160, 172, 0.5);
}
.field input:focus {
  border-color: rgba(255, 140, 26, 0.7);
  border-left-color: var(--orange);
  background: rgba(255, 140, 26, 0.07);
  box-shadow: 0 0 0 3px rgba(255, 140, 26, 0.1), 0 0 22px rgba(255, 140, 26, 0.16);
}

.toggle-eye {
  position: absolute;
  right: 10px;
  bottom: 9px;
  background: none;
  border: 0;
  cursor: pointer;
  padding: 4px;
  color: var(--text-dim);
  transition: 0.2s;
  line-height: 0;
}
.toggle-eye:hover,
.toggle-eye.active {
  color: var(--orange);
}

.meter {
  display: flex;
  align-items: center;
  gap: 5px;
  margin-top: 9px;
  opacity: 0;
  transition: opacity 0.25s;
}
.meter.on {
  opacity: 1;
}
.meter span {
  flex: 1;
  height: 3px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 2px;
  transition: 0.25s;
}
.meter span.lit {
  background: var(--orange);
  box-shadow: 0 0 8px rgba(255, 140, 26, 0.6);
}
.meter em {
  width: 34px;
  text-align: right;
  font-size: 10px;
  font-style: normal;
  color: var(--orange-soft);
}

.tiny-err {
  min-height: 14px;
  margin-top: 6px;
  font-size: 10.5px;
  color: #ff6b6b;
}

.btn {
  position: relative;
  width: 100%;
  padding: 14px;
  margin-top: 2px;
  border: 0;
  border-radius: 3px;
  cursor: pointer;
  font-family: var(--font-serif);
  font-size: 15px;
  font-weight: 700;
  letter-spacing: 0.34em;
  color: #1a0d02;
  background: linear-gradient(135deg, var(--orange-soft), var(--orange) 45%, var(--orange-deep));
  box-shadow: 0 6px 22px rgba(232, 98, 13, 0.35), 0 0 0 1px rgba(255, 255, 255, 0.12) inset;
  overflow: hidden;
  transition: 0.25s;
}
.btn::after {
  content: '';
  position: absolute;
  top: 0;
  left: -120%;
  width: 60%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.55), transparent);
  transform: skewX(-22deg);
}
.btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 30px rgba(232, 98, 13, 0.5), 0 0 0 1px rgba(255, 255, 255, 0.2) inset;
}
.btn:hover::after {
  left: 140%;
  transition: left 0.7s ease;
}

.btn.ghost {
  margin-top: 10px;
  background: transparent;
  color: var(--orange-soft);
  border: 1px solid rgba(255, 140, 26, 0.45);
  box-shadow: none;
  font-size: 12px;
}
.btn.ghost:hover {
  background: rgba(255, 140, 26, 0.12);
}

.done {
  text-align: center;
  animation: rise 0.5s both;
}
.done .mark {
  width: 78px;
  height: 78px;
  margin: 4px auto 18px;
  border-radius: 50%;
  border: 2px solid var(--orange);
  display: grid;
  place-items: center;
  box-shadow: 0 0 50px rgba(255, 140, 26, 0.4), 0 0 0 8px rgba(255, 140, 26, 0.06);
  animation: pulse 1.8s ease-in-out infinite;
}
.done h2 {
  font-family: var(--font-serif);
  font-size: 24px;
  letter-spacing: 0.3em;
  color: var(--orange-soft);
  text-shadow: 0 0 30px rgba(255, 140, 26, 0.55);
}
.done .who {
  margin: 14px 0 24px;
  font-size: 12.5px;
  color: var(--text-dim);
  letter-spacing: 0.08em;
}
.done .who em {
  font-style: normal;
  color: var(--chakra);
}

.err {
  color: #ff6b6b;
  font-size: 11.5px;
  letter-spacing: 0.06em;
  margin-top: 12px;
  text-align: center;
  min-height: 16px;
}
.err.ok {
  color: #7ee08a;
}

.card.shake {
  animation: shake 0.4s;
}

.links {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  margin-top: 12px;
  font-size: 11px;
  letter-spacing: 0.14em;
}
.links .dot {
  color: rgba(255, 140, 26, 0.45);
}
.lnk {
  color: var(--orange-soft);
  text-decoration: none;
  padding: 4px 2px;
  border-bottom: 1px dashed rgba(255, 140, 26, 0.4);
  transition: 0.22s;
}
.lnk:hover {
  color: #fff;
  border-bottom-color: var(--orange);
  text-shadow: 0 0 14px rgba(255, 140, 26, 0.7);
}

@media (max-width: 460px) {
  .card {
    padding: 24px 20px 20px;
  }
  h1 {
    font-size: 21px;
  }
  .steps span {
    padding: 4px 6px;
  }
}
</style>
