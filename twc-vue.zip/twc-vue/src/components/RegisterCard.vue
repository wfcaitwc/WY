<script setup>
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import VortexEmblem from './VortexEmblem.vue'
import {
  MIN_PWD,
  SECURITY_QUESTIONS,
  STRENGTH_TEXT,
  pwdStrength,
  useAuthStore,
  validEmail,
  validUid
} from '../stores/authStore'

const emit = defineEmits(['success'])

const RANKS = [
  { value: '下忍 · Genin', label: '下忍 · Genin' },
  { value: '中忍 · Chunin', label: '中忍 · Chunin' },
  { value: '上忍 · Jonin', label: '上忍 · Jonin' },
  { value: '影 · Kage', label: '影 · Kage' }
]

const { register, uidTaken, emailTaken } = useAuthStore()

const uid = ref('')
const email = ref('')
const rank = ref(RANKS[0].value)
const pwd = ref('')
const pwd2 = ref('')
const question = ref(SECURITY_QUESTIONS[0])
const answer = ref('')
const agree = ref(false)

const showPwd = ref(false)
const showPwd2 = ref(false)
const error = ref('')
const shaking = ref(false)

// 入场动画只在挂载后的短暂窗口内存在，避免与 shake 互相触发重播
const entering = ref(true)
let enterTimer = null

onMounted(() => {
  enterTimer = setTimeout(() => {
    entering.value = false
    enterTimer = null
  }, 800)
})

onBeforeUnmount(() => {
  if (enterTimer) clearTimeout(enterTimer)
})

function onAnimationEnd(e) {
  if (e.animationName === 'shake') shaking.value = false
}

function fail(msg) {
  error.value = msg
  shaking.value = false
  requestAnimationFrame(() => {
    shaking.value = true
  })
}

const strength = computed(() => pwdStrength(pwd.value))
const strengthText = computed(() => (pwd.value ? STRENGTH_TEXT[strength.value] : ''))

const pwdError = computed(() => {
  if (!pwd.value) return ''
  if (pwd.value.length < MIN_PWD) return `※ 密码不足 ${MIN_PWD} 位`
  return ''
})

const pwd2Error = computed(() => {
  if (!pwd2.value) return ''
  if (pwd2.value !== pwd.value) return '※ 两次输入的密码不一致'
  return ''
})

/* ---------------- 编号 / 邮箱 占用实时校验 ---------------- */
/**
 * 状态流转：idle 未校验 → checking 查询中 → free 可用 / taken 已占用 / invalid 格式有误
 * 失焦即查后端 /check-uid、/check-email，不等到提交才报错。
 */
const uidState = ref('idle')
const emailState = ref('idle')

const HINT = {
  uid: {
    checking: '※ 正在查阅户籍册…',
    free: '※ 该编号可用',
    taken: '※ 该忍者编号已被登记',
    invalid: '※ 编号需为 2-20 位字母、数字或下划线'
  },
  email: {
    checking: '※ 正在查阅户籍册…',
    free: '※ 该邮箱可用',
    taken: '※ 该邮箱已被登记',
    invalid: '※ 邮箱地址格式有误'
  }
}

const uidHint = computed(() => (uidState.value === 'idle' ? '' : HINT.uid[uidState.value]))
const emailHint = computed(() => (emailState.value === 'idle' ? '' : HINT.email[emailState.value]))

// 重新输入即作废上一次结论；seq 用来丢弃已过期的查询响应
let uidSeq = 0
let emailSeq = 0

async function onUidBlur() {
  const u = uid.value.trim()
  if (!u) {
    uidState.value = 'idle'
    return
  }
  if (!validUid(u)) {
    uidState.value = 'invalid'
    return
  }
  const seq = ++uidSeq
  uidState.value = 'checking'
  const taken = await uidTaken(u)
  if (seq !== uidSeq) return
  uidState.value = taken ? 'taken' : 'free'
}

async function onEmailBlur() {
  const e = email.value.trim()
  if (!e) {
    emailState.value = 'idle'
    return
  }
  if (!validEmail(e)) {
    emailState.value = 'invalid'
    return
  }
  const seq = ++emailSeq
  emailState.value = 'checking'
  const taken = await emailTaken(e)
  if (seq !== emailSeq) return
  emailState.value = taken ? 'taken' : 'free'
}

watch(uid, () => {
  uidSeq++
  uidState.value = 'idle'
})
watch(email, () => {
  emailSeq++
  emailState.value = 'idle'
})

const loading = ref(false)

async function onSubmit() {
  if (loading.value) return
  error.value = ''

  // 已在失焦时查出占用就直接拦下，省一次提交往返
  if (uidState.value === 'taken') return fail('※ 该忍者编号已被登记')
  if (uidState.value === 'invalid') return fail('※ 编号需为 2-20 位字母、数字或下划线')
  if (emailState.value === 'taken') return fail('※ 该邮箱已被登记')
  if (emailState.value === 'invalid') return fail('※ 邮箱地址格式有误')
  if (pwd.value.length < MIN_PWD) return fail(`※ 密码至少要 ${MIN_PWD} 位，查克拉不足`)
  if (pwd.value !== pwd2.value) return fail('※ 两次输入的密码不一致')
  if (!agree.value) return fail('※ 请先阅读并同意忍者守则')

  loading.value = true
  try {
    // 提交到后端，由 Spring Boot + MyBatis-Plus 写入 MySQL
    const res = await register({
      uid: uid.value,
      rank: rank.value,
      email: email.value,
      pwd: pwd.value,
      question: question.value,
      answer: answer.value
    })

    if (!res.ok) return fail(res.msg)

    emit('success', {
      uid: res.data?.uid || uid.value.trim(),
      rank: res.data?.ninjaRank || rank.value
    })
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <main class="card" :class="{ shake: shaking, entering }" @animationend="onAnimationEnd">
    <span class="corner tl"></span>
    <span class="corner tr"></span>
    <span class="corner bl"></span>
    <span class="corner br"></span>

    <div class="emblem-wrap">
      <VortexEmblem />
    </div>

    <h1>忍 者 注 册</h1>
    <p class="sub">ninja registration terminal</p>

    <div class="divider">新 忍 登 记</div>

    <form autocomplete="off" @submit.prevent="onSubmit">
      <div class="field">
        <label for="r-uid"><i></i>忍者编号</label>
        <input
          id="r-uid"
          v-model="uid"
          type="text"
          placeholder="2-20 位字母、数字或下划线，例：Naruto_01"
          maxlength="20"
          @blur="onUidBlur"
        />
        <p class="tiny-err" :class="uidState">{{ uidHint }}</p>
      </div>

      <div class="field">
        <label for="r-email"><i></i>邮箱地址（用于找回密码）</label>
        <input
          id="r-email"
          v-model="email"
          type="email"
          placeholder="例：ninja@example.com"
          maxlength="60"
          @blur="onEmailBlur"
        />
        <p class="tiny-err" :class="emailState">{{ emailHint }}</p>
      </div>

      <div class="field">
        <label for="r-rank"><i></i>忍者等级</label>
        <select id="r-rank" v-model="rank">
          <option v-for="r in RANKS" :key="r.value" :value="r.value">{{ r.label }}</option>
        </select>
      </div>

      <div class="field">
        <label for="r-pwd">
          <i></i>设置密码
          <span class="counter" :class="{ bad: pwdError }">{{ pwd.length }} / {{ MIN_PWD }}+</span>
        </label>
        <input
          id="r-pwd"
          v-model="pwd"
          :type="showPwd ? 'text' : 'password'"
          :placeholder="`至少 ${MIN_PWD} 位，建议混合大小写与数字`"
          maxlength="32"
        />
        <button
          type="button"
          class="toggle-eye"
          :class="{ active: showPwd }"
          :aria-label="showPwd ? '隐藏密码' : '显示密码'"
          @click="showPwd = !showPwd"
        >
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z" />
            <circle cx="12" cy="12" r="3" />
          </svg>
        </button>

        <div class="meter" :class="{ on: pwd.length > 0 }">
          <span v-for="i in 4" :key="i" :class="{ lit: i <= strength }"></span>
          <em v-if="strengthText">{{ strengthText }}</em>
        </div>
        <p class="tiny-err">{{ pwdError }}</p>
      </div>

      <div class="field">
        <label for="r-pwd2"><i></i>确认密码</label>
        <input
          id="r-pwd2"
          v-model="pwd2"
          :type="showPwd2 ? 'text' : 'password'"
          placeholder="再次输入相同密码"
          maxlength="32"
        />
        <button
          type="button"
          class="toggle-eye"
          :class="{ active: showPwd2 }"
          :aria-label="showPwd2 ? '隐藏密码' : '显示密码'"
          @click="showPwd2 = !showPwd2"
        >
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z" />
            <circle cx="12" cy="12" r="3" />
          </svg>
        </button>
        <p class="tiny-err">{{ pwd2Error }}</p>
      </div>

      <div class="divider">密 码 找 回 设 定</div>

      <div class="field">
        <label for="r-q"><i></i>安全问题</label>
        <select id="r-q" v-model="question">
          <option v-for="q in SECURITY_QUESTIONS" :key="q" :value="q">{{ q }}</option>
        </select>
      </div>

      <div class="field">
        <label for="r-a"><i></i>问题答案</label>
        <input id="r-a" v-model="answer" type="text" placeholder="忘记密码时用以核验身份" maxlength="30" />
      </div>

      <label class="agree">
        <input v-model="agree" type="checkbox" />
        <span>我已阅读并同意<b>忍者守则</b>，理解账号信息仅存于本机</span>
      </label>

      <button type="submit" class="btn">注 册 · 结 印</button>
      <p class="err">{{ error }}</p>
    </form>

    <nav class="links">
      <RouterLink class="lnk" to="/login">返 回 登 录</RouterLink>
      <span class="dot">·</span>
      <RouterLink class="lnk" to="/forgot">忘 记 密 码 ？</RouterLink>
    </nav>
  </main>
</template>

<style scoped>
.card {
  position: relative;
  z-index: 5;
  margin: auto;
  width: min(92vw, 448px);
  padding: 32px 34px 26px;
  background: linear-gradient(160deg, rgba(20, 24, 32, 0.92), rgba(8, 10, 14, 0.95));
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  border: 1px solid rgba(255, 140, 26, 0.28);
  border-radius: 6px;
  box-shadow:
    0 0 0 1px rgba(0, 0, 0, 0.6),
    0 30px 70px rgba(0, 0, 0, 0.75),
    0 0 60px rgba(255, 140, 26, 0.09) inset;
}

.card.entering {
  animation: rise 0.7s cubic-bezier(0.2, 0.8, 0.25, 1) both;
}

.card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 12%;
  right: 12%;
  height: 2px;
  background: linear-gradient(90deg, transparent, var(--orange), var(--chakra), transparent);
  box-shadow: 0 0 14px rgba(255, 140, 26, 0.7);
}

.corner {
  position: absolute;
  width: 16px;
  height: 16px;
  border: 2px solid var(--orange);
  opacity: 0.65;
}
.corner.tl { top: -1px; left: -1px; border-right: 0; border-bottom: 0; }
.corner.tr { top: -1px; right: -1px; border-left: 0; border-bottom: 0; }
.corner.bl { bottom: -1px; left: -1px; border-right: 0; border-top: 0; }
.corner.br { bottom: -1px; right: -1px; border-left: 0; border-top: 0; }

.emblem-wrap {
  display: flex;
  justify-content: center;
  margin-bottom: 12px;
}

h1 {
  font-family: var(--font-serif);
  font-size: 25px;
  letter-spacing: 0.22em;
  text-align: center;
  font-weight: 700;
  background: linear-gradient(180deg, #fff3e0, var(--orange-soft) 55%, var(--orange-deep));
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  text-shadow: 0 0 26px rgba(255, 140, 26, 0.35);
}

.sub {
  text-align: center;
  font-size: 11px;
  letter-spacing: 0.34em;
  color: var(--text-dim);
  margin-top: 9px;
  text-transform: uppercase;
}

.divider {
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 18px 0 20px;
  color: rgba(255, 140, 26, 0.5);
  font-size: 10px;
  letter-spacing: 0.3em;
}
.divider::before,
.divider::after {
  content: '';
  flex: 1;
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(255, 140, 26, 0.5), transparent);
}

.field {
  position: relative;
  margin-bottom: 18px;
}

.field label {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 11px;
  letter-spacing: 0.16em;
  color: var(--text-dim);
  margin-bottom: 8px;
}

.field label i {
  width: 5px;
  height: 5px;
  background: var(--orange);
  border-radius: 50%;
  box-shadow: 0 0 8px var(--orange);
  font-style: normal;
}

.counter {
  margin-left: auto;
  font-size: 10px;
  letter-spacing: 0.08em;
  color: rgba(154, 160, 172, 0.7);
}
.counter.bad {
  color: #ff6b6b;
}

.field input,
.field select {
  width: 100%;
  padding: 11px 12px;
  background: rgba(255, 255, 255, 0.035);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-left: 2px solid rgba(255, 140, 26, 0.45);
  border-radius: 3px;
  color: var(--text);
  font-size: 14px;
  letter-spacing: 0.05em;
  font-family: inherit;
  outline: none;
  transition: 0.22s;
}

.field input::placeholder {
  color: rgba(154, 160, 172, 0.5);
}

.field input:focus,
.field select:focus {
  border-color: rgba(255, 140, 26, 0.7);
  border-left-color: var(--orange);
  background: rgba(255, 140, 26, 0.07);
  box-shadow: 0 0 0 3px rgba(255, 140, 26, 0.1), 0 0 22px rgba(255, 140, 26, 0.16);
}

.field select {
  appearance: none;
  -webkit-appearance: none;
  cursor: pointer;
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'><path d='M2 4l4 4 4-4' stroke='%23ff8c1a' stroke-width='1.6' fill='none' stroke-linecap='round'/></svg>");
  background-repeat: no-repeat;
  background-position: right 12px center;
}

.field select option {
  background: #121620;
  color: var(--text);
}

.toggle-eye {
  position: absolute;
  right: 10px;
  bottom: 9px;
  background: none;
  border: 0;
  cursor: pointer;
  padding: 4px;
  color: var(--text-dim);
  transition: 0.2s;
  line-height: 0;
}
.toggle-eye:hover,
.toggle-eye.active {
  color: var(--orange);
}

.meter {
  display: flex;
  align-items: center;
  gap: 5px;
  margin-top: 9px;
  opacity: 0;
  transition: opacity 0.25s;
}
.meter.on {
  opacity: 1;
}

.meter span {
  flex: 1;
  height: 3px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 2px;
  transition: 0.25s;
}
.meter span.lit {
  background: var(--orange);
  box-shadow: 0 0 8px rgba(255, 140, 26, 0.6);
}
.meter em {
  width: 34px;
  text-align: right;
  font-size: 10px;
  font-style: normal;
  color: var(--orange-soft);
  letter-spacing: 0.08em;
}

.tiny-err {
  min-height: 14px;
  margin-top: 6px;
  font-size: 10.5px;
  color: #ff6b6b;
  letter-spacing: 0.05em;
}

/* 编号 / 邮箱 占用校验：可用走绿色，查询中走灰色，占用与格式错误沿用红色 */
.tiny-err.free {
  color: #5ddb8a;
}
.tiny-err.checking {
  color: rgba(154, 160, 172, 0.7);
}

.agree {
  display: flex;
  align-items: flex-start;
  gap: 9px;
  margin: 4px 0 18px;
  font-size: 11px;
  line-height: 1.6;
  color: var(--text-dim);
  cursor: pointer;
  letter-spacing: 0.05em;
}
.agree input {
  accent-color: var(--orange);
  width: 14px;
  height: 14px;
  margin-top: 2px;
  cursor: pointer;
  flex: none;
}
.agree b {
  color: var(--orange-soft);
  font-weight: 600;
}

.btn {
  position: relative;
  width: 100%;
  padding: 14px;
  border: 0;
  border-radius: 3px;
  cursor: pointer;
  font-family: var(--font-serif);
  font-size: 15px;
  font-weight: 700;
  letter-spacing: 0.34em;
  color: #1a0d02;
  background: linear-gradient(135deg, var(--orange-soft), var(--orange) 45%, var(--orange-deep));
  box-shadow: 0 6px 22px rgba(232, 98, 13, 0.35), 0 0 0 1px rgba(255, 255, 255, 0.12) inset;
  overflow: hidden;
  transition: 0.25s;
}

.btn::after {
  content: '';
  position: absolute;
  top: 0;
  left: -120%;
  width: 60%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.55), transparent);
  transform: skewX(-22deg);
}

.btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 30px rgba(232, 98, 13, 0.5), 0 0 0 1px rgba(255, 255, 255, 0.2) inset;
}
.btn:hover::after {
  left: 140%;
  transition: left 0.7s ease;
}
.btn:active {
  transform: translateY(0);
}

.err {
  color: #ff6b6b;
  font-size: 11.5px;
  letter-spacing: 0.06em;
  margin-top: 12px;
  text-align: center;
  min-height: 16px;
}

.card.shake {
  animation: shake 0.4s;
}

.links {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  margin-top: 14px;
  font-size: 11px;
  letter-spacing: 0.14em;
}
.links .dot {
  color: rgba(255, 140, 26, 0.45);
}
.lnk {
  color: var(--orange-soft);
  text-decoration: none;
  padding: 4px 2px;
  border-bottom: 1px dashed rgba(255, 140, 26, 0.4);
  transition: 0.22s;
}
.lnk:hover {
  color: #fff;
  border-bottom-color: var(--orange);
  text-shadow: 0 0 14px rgba(255, 140, 26, 0.7);
}

@media (max-width: 460px) {
  .card {
    padding: 24px 20px 20px;
  }
  h1 {
    font-size: 21px;
  }
}
</style>
