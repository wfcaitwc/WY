<script setup>
import { useNinjaStore } from '../../stores/ninjaStore'

const { state } = useNinjaStore()

const NEWS = [
  { date: '09.18', text: '中忍考试第三次选拔将于明日举行，请相关人员提前报到。' },
  { date: '09.17', text: '第三代火影训示：任务结束后务必提交完整报告卷轴。' },
  { date: '09.15', text: '训练场夜间开放时间延长至亥时，禁止私自使用禁术。' }
]

function fmt(ts) {
  const d = new Date(ts)
  const p = (n) => String(n).padStart(2, '0')
  return `${p(d.getHours())}:${p(d.getMinutes())}`
}
</script>

<template>
  <section class="panel">
    <header class="panel-head">
      <span class="dot"></span>木叶快报
    </header>

    <ul class="news">
      <li v-for="n in NEWS" :key="n.text">
        <span class="date">{{ n.date }}</span>
        <span class="text">{{ n.text }}</span>
      </li>
    </ul>

    <header class="panel-head sub">
      <span class="dot"></span>任务日志
    </header>

    <ul v-if="state.log.length" class="log">
      <li v-for="(l, i) in state.log.slice(0, 8)" :key="l.at + '-' + i">
        <span class="time">{{ fmt(l.at) }}</span>
        <span class="text">{{ l.text }}</span>
      </li>
    </ul>
    <p v-else class="empty">尚无记录，去任务卷轴接受第一个任务吧。</p>
  </section>
</template>

<style scoped>
.panel {
  background: linear-gradient(160deg, rgba(20, 24, 32, 0.92), rgba(8, 10, 14, 0.95));
  border: 1px solid rgba(255, 140, 26, 0.26);
  border-radius: 6px;
  padding: 18px;
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  box-shadow: 0 18px 44px rgba(0, 0, 0, 0.55);
}

.panel-head {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 11px;
  letter-spacing: 0.28em;
  color: var(--orange-soft);
  padding-bottom: 12px;
  border-bottom: 1px solid rgba(255, 140, 26, 0.18);
  margin-bottom: 12px;
}

.panel-head.sub {
  margin-top: 20px;
}

.panel-head .dot {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: var(--orange);
  box-shadow: 0 0 8px var(--orange);
}

.news,
.log {
  list-style: none;
  display: grid;
  gap: 10px;
}

.news li,
.log li {
  display: grid;
  grid-template-columns: 42px 1fr;
  gap: 10px;
  font-size: 11.5px;
  line-height: 1.6;
}

.date,
.time {
  color: var(--orange-soft);
  font-size: 10.5px;
  letter-spacing: 0.06em;
  padding-top: 1px;
}

.text {
  color: var(--text-dim);
}

.log .text {
  color: var(--text);
  opacity: 0.85;
}

.empty {
  font-size: 11px;
  color: var(--text-dim);
  line-height: 1.7;
  opacity: 0.7;
}
</style>
