<script setup>
import { computed, onBeforeUnmount, ref } from 'vue'
import { useNinjaStore } from '../../stores/ninjaStore'

const { state, tasks, activeTask, accept, complete, abandon } = useNinjaStore()

const RANK_COLOR = {
  S: '#ff3b3b',
  A: '#ff8c1a',
  B: '#ffd54a',
  C: '#3fd0ff',
  D: '#7fb069'
}

const tip = ref('')
let tipTimer = null

function showTip(text) {
  tip.value = text
  if (tipTimer) clearTimeout(tipTimer)
  tipTimer = setTimeout(() => {
    tip.value = ''
    tipTimer = null
  }, 2400)
}

const doneCount = computed(() => state.doneIds.length)

function onAccept(task) {
  const r = accept(task)
  showTip(r.ok ? `已接受：${task.title}` : r.msg)
}

function onComplete() {
  const r = complete()
  showTip(r.ok ? `任务完成！+${r.task.exp} 经验` : r.msg)
}

function onAbandon() {
  const r = abandon()
  showTip(r.ok ? '已放弃任务，返还一半查克拉' : r.msg)
}

onBeforeUnmount(() => {
  if (tipTimer) clearTimeout(tipTimer)
})
</script>

<template>
  <section class="panel">
    <header class="panel-head">
      <span class="dot"></span>任务卷轴
      <span class="count">已完成 {{ doneCount }} / {{ tasks.length }}</span>
    </header>

    <ul class="task-list">
      <li v-for="t in tasks" :key="t.id" class="task" :class="t.status">
        <span class="rank" :style="{ color: RANK_COLOR[t.rank], borderColor: RANK_COLOR[t.rank] }">
          {{ t.rank }}
        </span>

        <div class="body">
          <h3>{{ t.title }}</h3>
          <p class="desc">{{ t.desc }}</p>
          <div class="meta">
            <span>查克拉 <b>-{{ t.chakra }}</b></span>
            <span>经验 <b>+{{ t.exp }}</b></span>
          </div>
        </div>

        <div class="action">
          <template v-if="t.status === 'done'">
            <span class="done-tag">已 完 成</span>
          </template>
          <template v-else-if="t.status === 'active'">
            <button type="button" class="btn-mini ok" @click="onComplete">完成</button>
            <button type="button" class="btn-mini no" @click="onAbandon">放弃</button>
          </template>
          <template v-else>
            <button
              type="button"
              class="btn-mini"
              :disabled="!!activeTask || state.chakra < t.chakra"
              @click="onAccept(t)"
            >
              接受
            </button>
          </template>
        </div>
      </li>
    </ul>

    <p class="tip">{{ tip }}</p>
  </section>
</template>

<style scoped>
.panel {
  background: linear-gradient(160deg, rgba(20, 24, 32, 0.92), rgba(8, 10, 14, 0.95));
  border: 1px solid rgba(255, 140, 26, 0.26);
  border-radius: 6px;
  padding: 18px;
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  box-shadow: 0 18px 44px rgba(0, 0, 0, 0.55);
}

.panel-head {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 11px;
  letter-spacing: 0.28em;
  color: var(--orange-soft);
  padding-bottom: 12px;
  border-bottom: 1px solid rgba(255, 140, 26, 0.18);
  margin-bottom: 6px;
}

.panel-head .dot {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: var(--orange);
  box-shadow: 0 0 8px var(--orange);
}

.count {
  margin-left: auto;
  letter-spacing: 0.1em;
  color: var(--text-dim);
}

.task-list {
  list-style: none;
  max-height: 420px;
  overflow-y: auto;
  padding-right: 4px;
}

.task-list::-webkit-scrollbar {
  width: 4px;
}
.task-list::-webkit-scrollbar-thumb {
  background: rgba(255, 140, 26, 0.35);
  border-radius: 2px;
}

.task {
  display: grid;
  grid-template-columns: 30px 1fr auto;
  gap: 12px;
  align-items: center;
  padding: 13px 4px;
  border-bottom: 1px dashed rgba(255, 255, 255, 0.07);
}

.task:last-child {
  border-bottom: 0;
}

.task.done {
  opacity: 0.42;
}

.task.active {
  background: rgba(255, 140, 26, 0.06);
  box-shadow: inset 2px 0 0 var(--orange);
  padding-left: 10px;
}

.rank {
  width: 30px;
  height: 30px;
  border-radius: 4px;
  border: 1.5px solid;
  display: grid;
  place-items: center;
  font-family: var(--font-serif);
  font-weight: 700;
  font-size: 14px;
  flex: none;
}

.body h3 {
  font-size: 13.5px;
  font-weight: 600;
  letter-spacing: 0.04em;
  color: var(--text);
}

.desc {
  font-size: 10.5px;
  color: var(--text-dim);
  margin-top: 3px;
  line-height: 1.5;
}

.meta {
  display: flex;
  gap: 14px;
  margin-top: 6px;
  font-size: 10px;
  letter-spacing: 0.06em;
  color: var(--text-dim);
}

.meta b {
  font-weight: 600;
}

.meta span:first-child b {
  color: var(--chakra);
}
.meta span:last-child b {
  color: var(--orange-soft);
}

.action {
  display: flex;
  gap: 6px;
  flex: none;
}

.btn-mini {
  padding: 6px 12px;
  font-size: 11px;
  letter-spacing: 0.1em;
  cursor: pointer;
  border-radius: 3px;
  border: 1px solid rgba(255, 140, 26, 0.5);
  background: rgba(255, 140, 26, 0.1);
  color: var(--orange-soft);
  font-family: inherit;
  transition: 0.2s;
  white-space: nowrap;
}

.btn-mini:hover:not(:disabled) {
  background: rgba(255, 140, 26, 0.24);
  box-shadow: 0 0 16px rgba(255, 140, 26, 0.28);
}

.btn-mini:disabled {
  opacity: 0.3;
  cursor: not-allowed;
}

.btn-mini.ok {
  border-color: rgba(127, 176, 105, 0.6);
  background: rgba(127, 176, 105, 0.14);
  color: #b6e0a0;
}

.btn-mini.ok:hover {
  background: rgba(127, 176, 105, 0.3);
  box-shadow: 0 0 16px rgba(127, 176, 105, 0.3);
}

.btn-mini.no {
  border-color: rgba(255, 107, 107, 0.5);
  background: rgba(255, 107, 107, 0.1);
  color: #ff9b9b;
}

.btn-mini.no:hover {
  background: rgba(255, 107, 107, 0.24);
  box-shadow: 0 0 16px rgba(255, 107, 107, 0.26);
}

.done-tag {
  font-size: 10px;
  letter-spacing: 0.16em;
  color: var(--text-dim);
  white-space: nowrap;
}

.tip {
  min-height: 15px;
  margin-top: 10px;
  text-align: center;
  font-size: 10.5px;
  color: var(--orange-soft);
  letter-spacing: 0.06em;
}

@media (max-width: 460px) {
  .task {
    grid-template-columns: 26px 1fr;
  }
  .action {
    grid-column: 1 / -1;
    justify-content: flex-end;
  }
}
</style>
