<script setup>
import { onBeforeUnmount, ref } from 'vue'
import { useNinjaStore } from '../../stores/ninjaStore'

const { state, level, expPercent, chakraPercent, attrs, doneCount, rest, expPerLevel } = useNinjaStore()

const tip = ref('')
let tipTimer = null

function showTip(text) {
  tip.value = text
  if (tipTimer) clearTimeout(tipTimer)
  tipTimer = setTimeout(() => {
    tip.value = ''
    tipTimer = null
  }, 2200)
}

function doRest() {
  const r = rest()
  showTip(r.ok ? `冥想完毕，查克拉 +30（当前 ${chakraPercent.value}%）` : r.msg)
}

onBeforeUnmount(() => {
  if (tipTimer) clearTimeout(tipTimer)
})
</script>

<template>
  <section class="panel">
    <header class="panel-head">
      <span class="dot"></span>忍者资料
    </header>

    <div class="id-row">
      <div class="avatar">{{ (state.ninja?.uid || '?').slice(0, 1).toUpperCase() }}</div>
      <div class="id-meta">
        <strong>{{ state.ninja?.uid }}</strong>
        <span class="rank-tag">{{ state.ninja?.rank }}</span>
      </div>
      <div class="lv">Lv.{{ level }}</div>
    </div>

    <!-- 查克拉 -->
    <div class="gauge">
      <div class="gauge-top">
        <span>查克拉</span>
        <b>{{ state.chakra }} / 100</b>
      </div>
      <div class="bar chakra">
        <i :style="{ width: chakraPercent + '%' }"></i>
      </div>
    </div>

    <!-- 经验 -->
    <div class="gauge">
      <div class="gauge-top">
        <span>经验值</span>
        <b>{{ expPercent }} / {{ expPerLevel }}</b>
      </div>
      <div class="bar exp">
        <i :style="{ width: (expPercent / expPerLevel) * 100 + '%' }"></i>
      </div>
    </div>

    <!-- 八项数值 -->
    <div class="attrs">
      <div v-for="a in attrs" :key="a.name" class="attr">
        <span class="attr-name">{{ a.name }}</span>
        <div class="attr-bar">
          <i :style="{ width: (a.value / 10) * 100 + '%' }"></i>
        </div>
        <b>{{ a.value }}</b>
      </div>
    </div>

    <div class="stat-row">
      <div><b>{{ doneCount }}</b><span>完成任务</span></div>
      <div><b>{{ state.exp }}</b><span>累计经验</span></div>
    </div>

    <button type="button" class="rest-btn" @click="doRest">冥 想 恢 复</button>
    <p class="tip">{{ tip }}</p>
  </section>
</template>

<style scoped>
.panel {
  background: linear-gradient(160deg, rgba(20, 24, 32, 0.92), rgba(8, 10, 14, 0.95));
  border: 1px solid rgba(255, 140, 26, 0.26);
  border-radius: 6px;
  padding: 18px 18px 16px;
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  box-shadow: 0 18px 44px rgba(0, 0, 0, 0.55);
}

.panel-head {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 11px;
  letter-spacing: 0.28em;
  color: var(--orange-soft);
  padding-bottom: 12px;
  border-bottom: 1px solid rgba(255, 140, 26, 0.18);
  margin-bottom: 16px;
}

.panel-head .dot {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: var(--orange);
  box-shadow: 0 0 8px var(--orange);
}

.id-row {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 18px;
}

.avatar {
  width: 44px;
  height: 44px;
  border-radius: 50%;
  display: grid;
  place-items: center;
  font-family: var(--font-serif);
  font-size: 19px;
  font-weight: 700;
  color: #1a0d02;
  background: linear-gradient(135deg, var(--orange-soft), var(--orange) 50%, var(--orange-deep));
  box-shadow: 0 0 18px rgba(255, 140, 26, 0.4);
  flex: none;
}

.id-meta {
  flex: 1;
  min-width: 0;
}

.id-meta strong {
  display: block;
  font-size: 15px;
  letter-spacing: 0.06em;
  color: var(--text);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.rank-tag {
  display: inline-block;
  margin-top: 5px;
  padding: 2px 9px;
  font-size: 10px;
  letter-spacing: 0.16em;
  color: var(--orange-soft);
  border: 1px solid rgba(255, 140, 26, 0.42);
  border-radius: 2px;
  background: rgba(255, 140, 26, 0.08);
}

.lv {
  font-family: var(--font-serif);
  font-size: 20px;
  font-weight: 700;
  color: var(--chakra);
  text-shadow: 0 0 16px rgba(63, 208, 255, 0.5);
  flex: none;
}

.gauge {
  margin-bottom: 14px;
}

.gauge-top {
  display: flex;
  justify-content: space-between;
  font-size: 10.5px;
  letter-spacing: 0.16em;
  color: var(--text-dim);
  margin-bottom: 6px;
}

.gauge-top b {
  color: var(--text);
  font-weight: 600;
}

.bar {
  height: 9px;
  border-radius: 5px;
  background: rgba(255, 255, 255, 0.07);
  overflow: hidden;
  border: 1px solid rgba(255, 255, 255, 0.06);
}

.bar i {
  display: block;
  height: 100%;
  border-radius: 5px;
  transition: width 0.45s cubic-bezier(0.2, 0.8, 0.25, 1);
}

.bar.chakra i {
  background: linear-gradient(90deg, #2b8fd6, var(--chakra));
  background-size: 200% 100%;
  box-shadow: 0 0 14px rgba(63, 208, 255, 0.65);
  animation: chakra-flow 2.4s linear infinite;
}

@keyframes chakra-flow {
  to {
    background-position: -200% 0;
  }
}

.bar.exp i {
  background: linear-gradient(90deg, var(--orange-deep), var(--orange-soft));
  box-shadow: 0 0 14px rgba(255, 140, 26, 0.55);
}

.attrs {
  margin: 18px 0 14px;
  display: grid;
  gap: 8px;
}

.attr {
  display: grid;
  grid-template-columns: 44px 1fr 26px;
  align-items: center;
  gap: 9px;
}

.attr-name {
  font-size: 10.5px;
  letter-spacing: 0.08em;
  color: var(--text-dim);
}

.attr-bar {
  height: 6px;
  border-radius: 4px;
  background: rgba(255, 255, 255, 0.06);
  overflow: hidden;
}

.attr-bar i {
  display: block;
  height: 100%;
  border-radius: 4px;
  background: linear-gradient(90deg, var(--orange-deep), var(--orange));
  box-shadow: 0 0 10px rgba(255, 140, 26, 0.45);
  transition: width 0.5s ease;
}

.attr b {
  font-size: 11px;
  text-align: right;
  color: var(--orange-soft);
}

.stat-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  margin-bottom: 14px;
}

.stat-row div {
  text-align: center;
  padding: 9px 4px;
  border: 1px solid rgba(255, 255, 255, 0.07);
  border-radius: 4px;
  background: rgba(255, 255, 255, 0.03);
}

.stat-row b {
  display: block;
  font-family: var(--font-serif);
  font-size: 19px;
  color: var(--orange-soft);
}

.stat-row span {
  font-size: 10px;
  letter-spacing: 0.14em;
  color: var(--text-dim);
}

.rest-btn {
  width: 100%;
  padding: 10px;
  cursor: pointer;
  border-radius: 3px;
  border: 1px solid rgba(63, 208, 255, 0.45);
  background: rgba(63, 208, 255, 0.1);
  color: var(--chakra);
  font-family: var(--font-serif);
  font-size: 12px;
  letter-spacing: 0.28em;
  transition: 0.22s;
}

.rest-btn:hover {
  background: rgba(63, 208, 255, 0.2);
  box-shadow: 0 0 22px rgba(63, 208, 255, 0.28);
}

.tip {
  min-height: 15px;
  margin-top: 9px;
  text-align: center;
  font-size: 10.5px;
  color: var(--orange-soft);
  letter-spacing: 0.06em;
}

@media (max-width: 460px) {
  .attr {
    grid-template-columns: 40px 1fr 24px;
  }
}
</style>
