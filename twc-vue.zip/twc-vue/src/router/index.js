import { createRouter, createWebHashHistory } from 'vue-router'
import { useNinjaStore } from '../stores/ninjaStore'

const LoginView = () => import('../views/LoginView.vue')
const RegisterView = () => import('../views/RegisterView.vue')
const ForgotView = () => import('../views/ForgotView.vue')
const DashboardView = () => import('../views/DashboardView.vue')

const routes = [
  { path: '/', redirect: '/login' },
  { path: '/login', name: 'login', component: LoginView },
  { path: '/register', name: 'register', component: RegisterView },
  { path: '/forgot', name: 'forgot', component: ForgotView },
  { path: '/dashboard', name: 'dashboard', component: DashboardView },
  { path: '/:pathMatch(.*)*', redirect: '/login' }
]

const router = createRouter({
  // 使用 hash 模式：dist 直接以 file:// 打开也不会 404
  history: createWebHashHistory(),
  routes
})

router.beforeEach((to) => {
  const { isLogin } = useNinjaStore()

  if (to.name === 'dashboard' && !isLogin.value) {
    return { name: 'login' }
  }
  if (to.name === 'login' && isLogin.value) {
    return { name: 'dashboard' }
  }
  return true
})

export default router
