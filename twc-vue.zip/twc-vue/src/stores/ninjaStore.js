import { computed, reactive, watch } from 'vue'

/**
 * 忍者状态单例 store
 * 负责：当前忍者身份、查克拉、经验 / 等级、任务进度
 * 数据持久化到 localStorage
 */

const STORAGE_KEY = 'twc-ninja-v1'

/** 等级 → 八项数值基准 */
const RANK_BASE = [
  { key: '下忍', base: 4 },
  { key: '中忍', base: 6 },
  { key: '上忍', base: 8 },
  { key: '影', base: 10 }
]

/** 火影八项能力值 */
export const ATTRS = [
  { name: '忍术', offset: 0.6 },
  { name: '体术', offset: 0.2 },
  { name: '幻术', offset: -0.5 },
  { name: '力', offset: 0.1 },
  { name: '速度', offset: 0.8 },
  { name: '智力', offset: -0.2 },
  { name: '精神力', offset: 0.4 },
  { name: '幸运', offset: -0.6 }
]

/** 任务卷轴（等级越高，消耗查克拉越多，经验越多） */
export const TASKS = [
  { id: 'd1', rank: 'D', title: '寻回走失的忍猫', desc: '村内委托，难度极低，适合新人练手。', chakra: 8, exp: 10 },
  { id: 'd2', rank: 'D', title: '清理木叶训练场', desc: '打扫第三训练场，并归还散落的苦无。', chakra: 10, exp: 12 },
  { id: 'c1', rank: 'C', title: '护送商队至国境', desc: '沿途警戒，防范盗贼袭扰。', chakra: 18, exp: 26 },
  { id: 'c2', rank: 'C', title: '采集药草 · 毒谷调查', desc: '深入毒谷采集止血草，注意瘴气。', chakra: 20, exp: 30 },
  { id: 'b1', rank: 'B', title: '侦查边境异常查克拉', desc: '有报告称边境出现不明查克拉反应。', chakra: 30, exp: 48 },
  { id: 'b2', rank: 'B', title: '护卫大名使者', desc: '全程贴身护卫，禁止单独行动。', chakra: 34, exp: 55 },
  { id: 'a1', rank: 'A', title: '截获机密卷轴', desc: '敌方忍者携带我方机密，务必拦截。', chakra: 46, exp: 90 },
  { id: 's1', rank: 'S', title: '封印失控的尾兽查克拉', desc: '最高机密任务，仅限精锐执行。', chakra: 70, exp: 160 }
]

const EXP_PER_LEVEL = 100
const CHAKRA_MAX = 100
const REST_GAIN = 30

function defaultState() {
  return {
    ninja: null, // { uid, rank }
    chakra: CHAKRA_MAX,
    exp: 0,
    activeTaskId: null,
    doneIds: [],
    log: [] // 任务日志，最新在前
  }
}

function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return defaultState()
    const saved = JSON.parse(raw)
    return { ...defaultState(), ...saved }
  } catch {
    return defaultState()
  }
}

const state = reactive(load())

watch(
  state,
  (v) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(v))
    } catch {
      /* 忽略隐私模式下的写入失败 */
    }
  },
  { deep: true }
)

/* ---------------- 计算属性 ---------------- */

const isLogin = computed(() => !!state.ninja)

const level = computed(() => Math.floor(state.exp / EXP_PER_LEVEL) + 1)

const expPercent = computed(() => state.exp % EXP_PER_LEVEL)

const chakraPercent = computed(() => Math.round((state.chakra / CHAKRA_MAX) * 100))

const rankBase = computed(() => {
  if (!state.ninja) return 4
  const found = RANK_BASE.find((r) => state.ninja.rank.includes(r.key))
  return found ? found.base : 4
})

const attrs = computed(() =>
  ATTRS.map((a) => ({
    name: a.name,
    value: Math.min(10, Math.max(1, +(rankBase.value + a.offset + state.doneIds.length * 0.25).toFixed(1)))
  }))
)

const tasks = computed(() =>
  TASKS.map((t) => ({
    ...t,
    status: state.doneIds.includes(t.id)
      ? 'done'
      : state.activeTaskId === t.id
        ? 'active'
        : 'available'
  }))
)

const activeTask = computed(() => TASKS.find((t) => t.id === state.activeTaskId) || null)

/* ---------------- 行为 ---------------- */

function login(uid, rank) {
  state.ninja = { uid, rank }
}

function logout() {
  state.ninja = null
  state.activeTaskId = null
  state.chakra = CHAKRA_MAX
  state.exp = 0
  state.doneIds = []
  state.log = []
}

function pushLog(text) {
  state.log.unshift({ text, at: Date.now() })
  if (state.log.length > 20) state.log.pop()
}

function accept(task) {
  if (state.activeTaskId) return { ok: false, msg: '※ 已有正在执行的任务' }
  if (state.chakra < task.chakra) return { ok: false, msg: '※ 查克拉不足，请先休息' }
  state.chakra -= task.chakra
  state.activeTaskId = task.id
  pushLog(`接受任务：${task.title}`)
  return { ok: true }
}

function complete() {
  const task = activeTask.value
  if (!task) return { ok: false, msg: '※ 当前没有执行中的任务' }
  state.activeTaskId = null
  state.doneIds.push(task.id)
  state.exp += task.exp
  pushLog(`完成任务：${task.title}（+${task.exp} 经验）`)
  return { ok: true, task }
}

function abandon() {
  const task = activeTask.value
  if (!task) return { ok: false, msg: '※ 当前没有执行中的任务' }
  state.activeTaskId = null
  state.chakra = Math.min(CHAKRA_MAX, state.chakra + Math.round(task.chakra / 2))
  pushLog(`放弃任务：${task.title}（返还一半查克拉）`)
  return { ok: true }
}

function rest() {
  if (state.chakra >= CHAKRA_MAX) return { ok: false, msg: '※ 查克拉已满' }
  state.chakra = Math.min(CHAKRA_MAX, state.chakra + REST_GAIN)
  pushLog(`冥想恢复查克拉 +${REST_GAIN}`)
  return { ok: true }
}

export function useNinjaStore() {
  return {
    state,
    isLogin,
    level,
    expPercent,
    chakraPercent,
    chakraMax: CHAKRA_MAX,
    attrs,
    tasks,
    activeTask,
    doneCount: computed(() => state.doneIds.length),
    expPerLevel: EXP_PER_LEVEL,
    login,
    logout,
    accept,
    complete,
    abandon,
    rest
  }
}
