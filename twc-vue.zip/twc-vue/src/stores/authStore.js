import {
  apiCheckEmail,
  apiCheckUid,
  apiGetQuestion,
  apiLogin,
  apiRegister,
  apiResetPassword,
  apiVerify
} from '../api/ninjaApi'

/**
 * 忍者登记簿 store
 * 负责：注册、登录、身份核验、重置密码
 * 数据全部来自后端 Spring Boot（MyBatis-Plus + MySQL），本文件只做校验与请求编排。
 */

/** 密码最短长度：全局统一规则，与后端 NinjaUserServiceImpl.MIN_PWD 一致 */
export const MIN_PWD = 6

/** 注册 / 找回时可选的安全问题 */
export const SECURITY_QUESTIONS = [
  '你的第一只通灵兽叫什么名字？',
  '你的忍者学校导师是谁？',
  '你最擅长的术是什么？',
  '你的出身村（非木叶者亦可）？',
  '你第一次执行任务的地点？'
]

/* ---------------- 本地校验（与后端规则保持一致，用于即时提示） ---------------- */

export function validUid(uid) {
  return /^[A-Za-z0-9_]{2,20}$/.test(String(uid || '').trim())
}

export function validEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || '').trim())
}

export function validPwd(pwd) {
  return typeof pwd === 'string' && pwd.length >= MIN_PWD
}

/** 简易密码强度：0 ~ 4 */
export function pwdStrength(pwd) {
  if (!pwd) return 0
  let s = 0
  if (pwd.length >= MIN_PWD) s += 1
  if (pwd.length >= 10) s += 1
  if (/[a-z]/.test(pwd) && /[A-Z]/.test(pwd)) s += 1
  if (/\d/.test(pwd)) s += 1
  if (/[^A-Za-z0-9]/.test(pwd)) s += 1
  return Math.min(4, s)
}

export const STRENGTH_TEXT = ['极弱', '偏弱', '尚可', '良好', '极强']

/* ---------------- 行为（全部走后端接口） ---------------- */

export function useAuthStore() {
  /**
   * 注册新忍者
   * @returns {Promise<{ok: boolean, msg: string, data?: object}>}
   */
  async function register({ uid, rank, email, pwd, question, answer }) {
    const u = String(uid || '').trim()
    const e = String(email || '').trim()
    const a = String(answer || '').trim()

    // 前端先拦一遍，减少无谓请求；后端仍会二次校验
    if (!validUid(u)) return { ok: false, msg: '※ 编号需为 2-20 位字母、数字或下划线' }
    if (!validEmail(e)) return { ok: false, msg: '※ 邮箱地址格式有误' }
    if (!validPwd(pwd)) return { ok: false, msg: `※ 密码至少 ${MIN_PWD} 位` }
    if (!question) return { ok: false, msg: '※ 请选择安全问题' }
    if (!a) return { ok: false, msg: '※ 请填写安全问题答案' }

    const r = await apiRegister({ uid: u, email: e, ninjaRank: rank, password: pwd, question, answer: a })
    return { ok: r.ok, msg: r.ok ? '注册完成' : r.msg, data: r.data }
  }

  /**
   * 登录
   * @returns {Promise<{ok: boolean, msg: string, data?: object}>}
   */
  async function login({ uid, password }) {
    const u = String(uid || '').trim()
    if (!validUid(u)) return { ok: false, msg: '※ 编号至少 2 个字符' }
    if (!password) return { ok: false, msg: '※ 请填写密码' }

    const r = await apiLogin({ uid: u, password })
    return { ok: r.ok, msg: r.ok ? '认证成功' : r.msg, data: r.data }
  }

  /** 编号是否被占用（true 表示已占用） */
  async function uidTaken(uid) {
    if (!validUid(uid)) return false
    const r = await apiCheckUid(String(uid).trim())
    return r.ok ? !!r.data?.taken : false
  }

  /** 邮箱是否被占用（true 表示已占用） */
  async function emailTaken(email) {
    if (!validEmail(email)) return false
    const r = await apiCheckEmail(String(email).trim())
    return r.ok ? !!r.data?.taken : false
  }

  /**
   * 找回密码第一步：按编号取回安全问题
   * @returns {Promise<{ok: boolean, msg: string, question?: string}>}
   */
  async function getQuestion(uid) {
    const r = await apiGetQuestion(String(uid || '').trim())
    return { ok: r.ok, msg: r.msg, question: r.data }
  }

  /**
   * 找回密码第二步：核验邮箱与安全问题，成功后返回重置凭证
   * @returns {Promise<{ok: boolean, msg: string, resetToken?: string}>}
   */
  async function verifyIdentity(uid, email, answer) {
    const r = await apiVerify({
      uid: String(uid || '').trim(),
      email: String(email || '').trim(),
      answer: String(answer || '').trim()
    })
    return { ok: r.ok, msg: r.msg, resetToken: r.data }
  }

  /**
   * 找回密码第三步：凭凭证重置密码
   */
  async function resetPassword(resetToken, newPwd) {
    if (!resetToken) return { ok: false, msg: '※ 缺少重置凭证，请重新核验身份' }
    if (!validPwd(newPwd)) return { ok: false, msg: `※ 新密码至少 ${MIN_PWD} 位` }

    const r = await apiResetPassword({ resetToken, newPassword: newPwd })
    return { ok: r.ok, msg: r.ok ? '密码已重置，请使用新密码登录' : r.msg }
  }

  return {
    register,
    login,
    uidTaken,
    emailTaken,
    getQuestion,
    verifyIdentity,
    resetPassword
  }
}
