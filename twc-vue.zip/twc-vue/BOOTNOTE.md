# BOOTNOTE.md — AI 自检备忘录（每次会话请先读我）

> 给未来会话里的 WorkBuddy：接到本项目相关任务时，先读这份文件，避免重复分析。

## 1. 这个项目是什么
- 名称：`twc-vue`（火影忍者风格登录页「木叶隐村 · 忍者认证终端」）。
- 技术栈：Vue 3（Composition API + `<script setup>`）+ Vite 5，**纯前端**。
- 功能：登录 / 注册 / 找回密码 / 忍者终端主页（路由 hash 模式，登录守卫）。
- 账号数据存 `localStorage`（`twc-ninja-accounts-v1`），**无后端也能完整演示**。
- 可选后端：Spring Boot（默认 127.0.0.1:8081），由 `vite.config.js` 的 `proxy` 把 `/api` 转发过去；不启后端时 `src/api/ninjaApi.js` 会优雅降级提示，不影响页面。

## 2. 最重要的运行约束（务必记住）
- **每次开机电脑会重置**：项目里的 `node_modules` 和 `target` 会被清空，但用户目录下的 npm 缓存（`~/.npm`，本机为 `C:\Users\Administrator\AppData\Local\npm-cache`）**会保留**。
- 因此提速核心：**不要裸跑 `npm install`**。用 `npm ci --prefer-offline` 复用本地缓存，重置后重装约 **7 秒**（已实测，全缓存、不联网）。
- 任何启动/恢复脚本在运行前**不能假设 `node_modules`/`target` 已存在**，必须先装依赖。
- 已加 `.npmrc`：`prefer-offline=true`、`audit=false`、`fund=false`，让 `npm ci` 默认走缓存、少联网、少噪声。

## 3. 怎么启动 / 暂停（已写好脚本，GBK 编码，相对路径）
- 启动：双击 `启动.bat`
  - 自动 `cd` 到脚本目录 → 检测 `node_modules\vue` 是否存在 → 缺失则 `npm ci --prefer-offline` 恢复 → 后台开一个独立窗口跑 `npm run dev` → 浏览器自动打开 `http://localhost:5173`。
- 暂停：双击 `暂停.bat`
  - 按端口 5173 结束监听进程，并兜底关掉 `启动.bat` 打开的 `TWC-VUE-DEV` 窗口。
- 不要手动 `chcp 65001`：`.bat` 是 GBK，cmd 默认 GBK，切换反而让中文乱码。

## 4. 不要做的事
- 不要重写已经稳定的源码（组件/store/router）除非用户明确要求改功能。
- 不要在 `vite.config.js` 里删 `proxy` 的 `/api` 段——那是给后端用的，无后端也能跑。
- 不要依赖 `dist/`（已被 .gitignore，且重置会清）。

## 5. 已知优化 / 已处理项
- 已删 vite 遗留临时文件 `vite.config.js.timestamp-*.mjs`。
- 已给 `index.html` 加内联 SVG favicon（data URI，不额外请求文件）。
- 已加 `.npmrc` 与 `启动.bat` / `暂停.bat`。
- `npm ci` 验证：删 `node_modules` 后 7 秒恢复（33 个包，全来自缓存）。

## 6. 还缺什么（按需再补，非必须）
- 可选：ESLint / Prettier 规范；固定 Node 版本的 `.nvmrc`；真正的 Spring Boot 后端工程（当前只有前端，proxy 指向 8081 但后端不在本目录）。
- 若以后要加后端且后端是 Maven 工程，重置也会清 `target`，可参照同样的「缓存/离线恢复」思路写对应脚本。

## 7. 配套后端（2026-10-09 新增）
- 位置：`D:\workSpace\twc-ninja-server`（本机原来**没有** /api/ninja 后端，这是按 `src/api/ninjaApi.js` 契约新写的）。
- 技术栈：Spring Boot 3.3.4 + MyBatis-Plus 3.5.7 + Java 21，端口 **8081**。
- 接口：`/api/ninja/register|login|check-uid|check-email|question|verify|reset-password`，统一返回 `{code,msg,data}`（code=200 成功），七接口+异常路径已全部 curl 实测通过。
- 数据库：默认 **H2 文件库**（`./data/ninja.mv.db`，零配置，重置不丢）；切 MySQL：改 `application-mysql.properties` 密码、建库 `twc_ninja`，用 `后端启动.bat mysql`。
- 构建：Maven 内置在工程 `.mvn\maven`（阿里云镜像见 `.mvn\settings.xml`），依赖缓存在 `%USERPROFILE%\.m2`（重置后保留，只有 target 需重建）。
- 启动：`后端启动.bat`（target 缺失自动重建→独立窗口跑 `java -jar target/ninja-server.jar --server.port=8081`）；停止：`后端暂停.bat`。
- **坑**：启动命令必须显式 `--server.port=8081`，否则 WorkBuddy 注入的 `SERVER__PORT=58223` 环境变量会被 Spring 宽松绑定吃掉。
- 已有测试账号：`naruto` / `newpass888`（存在 H2 库里，可删 `data` 目录重置）。

## 8. 一句话结论
重置后变慢的根因是 `node_modules` 被删；用 `npm ci --prefer-offline`（配合保留的 `~/.npm` 缓存）把重装压到约 7 秒，并用 `启动.bat` / `暂停.bat` 一键管理；后端同理（`.mvn` 内置 Maven + `~/.m2` 缓存），是最省事、最稳的提速方案。
