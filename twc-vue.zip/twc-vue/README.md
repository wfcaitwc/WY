# 木叶隐村 · 忍者认证终端（Vue 3 版）

火影忍者风格登录页，由单文件 HTML 改造为 **Vue 3 + Vite** 工程。

## 快速开始

```bash
# 安装依赖
npm install

# 启动开发服务器（默认 http://localhost:5173）
npm run dev

# 生产构建，输出到 dist/
npm run build

# 预览构建产物
npm run preview
```

> `vite.config.js` 中已设置 `base: './'`，构建出的 `dist/index.html` 可直接双击打开。

## 目录结构

```
twc-vue/
├─ index.html                  入口 HTML
├─ vite.config.js              Vite 配置
├─ package.json
└─ src/
   ├─ main.js                  应用入口
   ├─ App.vue                  根组件：组合各层
   ├─ styles/
   │  └─ main.css              设计变量 / 重置 / 全局动画关键帧
   ├─ composables/
   │  └─ useChakraCanvas.js    查克拉粒子 + 漩涡 canvas 逻辑
   ├─ router/
   │  └─ index.js              路由与登录守卫（hash 模式）
   ├─ stores/
   │  ├─ ninjaStore.js         忍者状态：查克拉 / 经验 / 任务
   │  └─ authStore.js          忍者登记簿：注册 / 核验 / 重置密码
   ├─ views/
   │  ├─ LoginView.vue         登录页（/login）
   │  ├─ RegisterView.vue      注册页（/register）
   │  ├─ ForgotView.vue        找回密码页（/forgot）
   │  └─ DashboardView.vue     忍者终端主页（/dashboard）
   └─ components/
      ├─ ChakraBackground.vue  背景 canvas（螺旋 + 粒子）
      ├─ FallingLeaves.vue     飘落树叶（12 片，随机参数）
      ├─ VortexEmblem.vue      木叶漩涡徽章（SVG）
      ├─ SharinganEye.vue      写轮眼（SVG，缓慢旋转）
      ├─ LoginCard.vue         登录卡片与表单校验
      ├─ RegisterCard.vue      注册卡片（密码 ≥ 6 位 + 强度条）
      ├─ ForgotCard.vue        找回密码（编号 → 核验 → 重设，三步）
      └─ SealOverlay.vue       十二印结印动画 + 认证成功页
```

## 改造要点

| 原 HTML | Vue 改造 |
| --- | --- |
| 全局 `<style>` | `src/styles/main.css` + 组件 `<style scoped>` |
| 内联 `<script>` 操作 DOM | Vue 响应式数据 + `v-model` / `v-if` / `v-for` |
| `document.createElement` 生成树叶 | `v-for` 渲染，参数在 `setup` 中生成一次 |
| `classList.add('shake')` | `:class="{ shake }"` + `@animationend` 复位 |
| `setInterval` 驱动结印 | `watch` props + `computed`，卸载时自动清理定时器 |
| `setInterval` 直接改 DOM | `:key` 变更触发 CSS 动画重播 |
| — | `Transition` 组件实现遮罩淡入淡出 |

## 页面与交互

| 路由 | 页面 | 说明 |
| --- | --- | --- |
| `/login` | 登录 | 编号至少 **2** 个字符、密码至少 **4** 位，否则卡片抖动并提示 |
| `/register` | 注册 | 密码不少于 **6** 位，含强度条与二次确认；需填写邮箱 + 安全问题 |
| `/forgot` | 找回密码 | 编号 → 邮箱与安全问题核验 → 设置新密码（≥ 6 位），三步流程 |
| `/dashboard` | 忍者终端 | 需登录态，未登录会被守卫重定向到 `/login` |

- 登录 / 注册校验通过 → 播放十二地支结印（子→亥，每印 170ms）→ 显示「认证成功」
- 已注册的编号必须使用登记时的密码；未注册的编号仍按演示规则放行
- 点击「返回村口」清空表单并回到登录态
- 账号数据存于 `localStorage`（`twc-ninja-accounts-v1`），无任何后端请求

## 技术栈

- Vue 3.5（Composition API + `<script setup>`）
- Vite 5
- 零 UI 库、零外部素材，全部图形为 CSS / SVG / Canvas 绘制
