import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  // 使用相对路径，dist 可直接双击打开或部署到任意子目录
  base: './',
  server: {
    port: 5173,
    open: true,
    // /api 请求转发到 Spring Boot 后端，避免开发期跨域
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:8081',
        changeOrigin: true
      }
    }
  },
  build: {
    outDir: 'dist',
    assetsDir: 'assets'
  }
})
